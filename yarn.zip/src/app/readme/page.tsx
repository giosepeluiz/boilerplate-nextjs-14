import FetchReadme from "./components/FetchReadme";

const Readme: React.FC = () => {
  return <FetchReadme />;
};

export default Readme;
